# Django
export DEBUG=
export SECRET_KEY="yoursecret"
export DJANGO_ALLOWED_HOSTS=

# Database
export DATABASE='postgres'
export SQL_ENGINE=
export SQL_DATABASE=
export SQL_USER=
export SQL_PASSWORD=
export SQL_HOST="db"
export SQL_PORT="5432"
