from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = "todo.core.base"
    label = "todobase"
