default_app_config = "todo.core.base.apps.BaseConfig"
